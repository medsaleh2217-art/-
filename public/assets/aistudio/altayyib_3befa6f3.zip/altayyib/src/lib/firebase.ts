import { initializeApp } from 'firebase/app';
import { initializeFirestore, persistentLocalCache, persistentMultipleTabManager, type Firestore } from 'firebase/firestore';

const cfg = {
  apiKey: import.meta.env.VITE_FIREBASE_API_KEY as string | undefined,
  authDomain: import.meta.env.VITE_FIREBASE_AUTH_DOMAIN as string | undefined,
  projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID as string | undefined,
  storageBucket: import.meta.env.VITE_FIREBASE_STORAGE_BUCKET as string | undefined,
  messagingSenderId: import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID as string | undefined,
  appId: import.meta.env.VITE_FIREBASE_APP_ID as string | undefined,
};

export const firebaseConfigured = Boolean(cfg.apiKey && cfg.projectId && cfg.appId);

/** وضع البيانات التجريبية: للتطوير فقط (أو عند ضبط VITE_DEMO=true) وعند غياب إعداد Firebase */
export const demoMode =
  !firebaseConfigured && (import.meta.env.DEV || import.meta.env.VITE_DEMO === 'true');

export const app = firebaseConfigured ? initializeApp(cfg) : null;

export const db: Firestore | null = app
  ? initializeFirestore(app, {
      // تخزين محلي لتحسين التجربة عند ضعف الاتصال
      localCache: persistentLocalCache({ tabManager: persistentMultipleTabManager() }),
    })
  : null;

export const imageStorageMode: 'firestore' | 'storage' =
  import.meta.env.VITE_IMAGE_STORAGE === 'storage' ? 'storage' : 'firestore';
