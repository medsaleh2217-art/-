import { useData } from '../state/data';
import { telHref, waLink, waNumber } from './format';

/** يوفّر رابط واتساب فقط إذا أكّد المالك رقم واتساب من الإعدادات */
export function useWhatsApp() {
  const { settings } = useData();
  const enabled = waNumber(settings.whatsappNumber).length >= 8;
  const firstPhone = settings.phones[0];
  return {
    enabled,
    link: (text: string) => (enabled ? waLink(settings.whatsappNumber, text) : null),
    callHref: firstPhone ? telHref(firstPhone) : null,
  };
}
