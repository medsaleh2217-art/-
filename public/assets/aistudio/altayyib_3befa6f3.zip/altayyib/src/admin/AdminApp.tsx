import { useEffect, useState, type FormEvent } from 'react';
import { Link } from 'react-router-dom';
import { onAuthStateChanged, signInWithEmailAndPassword, signOut, type User } from 'firebase/auth';
import { doc, getDoc } from 'firebase/firestore';
import { db, firebaseConfigured } from '../lib/firebase';
import { auth } from '../lib/adminFirebase';
import { useI18n } from '../i18n';
import { useSeo } from '../lib/useSeo';
import Logo from '../components/Logo';
import CategoriesAdmin from './CategoriesAdmin';
import OrdersAdmin from './OrdersAdmin';
import ProductsAdmin from './ProductsAdmin';
import SettingsAdmin from './SettingsAdmin';

type Tab = 'orders' | 'products' | 'categories' | 'settings';
type Gate = 'loading' | 'out' | 'denied' | 'ok';

export default function AdminApp() {
  const { t, toggle } = useI18n();
  const [gate, setGate] = useState<Gate>('loading');
  const [user, setUser] = useState<User | null>(null);
  const [tab, setTab] = useState<Tab>('orders');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  useSeo({ title: t('admin.title'), noindex: true });

  useEffect(() => {
    if (!auth || !db) return;
    const database = db;
    return onAuthStateChanged(auth, async (u) => {
      setUser(u);
      if (!u) return setGate('out');
      setGate('loading');
      try {
        // التحقق الحقيقي في قواعد Firestore؛ هذا فقط لعرض الواجهة المناسبة
        const snap = await getDoc(doc(database, 'adminUsers', u.uid));
        setGate(snap.exists() ? 'ok' : 'denied');
      } catch {
        setGate('denied');
      }
    });
  }, []);

  if (!firebaseConfigured || !auth) {
    return (
      <div className="admin">
        <div className="login">
          <h1>{t('admin.title')}</h1>
          <p className="notice notice-warn">{t('admin.notConfigured')}</p>
          <Link to="/" className="btn btn-outline">
            {t('admin.viewSite')}
          </Link>
        </div>
      </div>
    );
  }

  const login = async (e: FormEvent) => {
    e.preventDefault();
    setBusy(true);
    setError('');
    try {
      await signInWithEmailAndPassword(auth!, email.trim(), password);
    } catch (err) {
      console.error(err);
      setError(t('admin.loginFailed'));
    } finally {
      setBusy(false);
    }
  };

  if (gate === 'loading') {
    return (
      <div className="admin">
        <p className="center page">{t('admin.checking')}</p>
      </div>
    );
  }

  if (gate === 'out' || !user) {
    return (
      <div className="admin">
        <form className="login" onSubmit={login}>
          <div style={{ marginBottom: 14 }}>
            <Logo />
          </div>
          <h1>{t('admin.login')}</h1>
          <label className="field">
            <span>{t('admin.email')}</span>
            <input className="input" dir="ltr" type="email" autoComplete="username" value={email} onChange={(e) => setEmail(e.target.value)} required />
          </label>
          <label className="field">
            <span>{t('admin.password')}</span>
            <input className="input" dir="ltr" type="password" autoComplete="current-password" value={password} onChange={(e) => setPassword(e.target.value)} required />
          </label>
          {error && <p className="notice notice-err">{error}</p>}
          <button type="submit" className="btn btn-primary btn-lg" style={{ width: '100%' }} disabled={busy}>
            {busy ? t('common.loading') : t('admin.signIn')}
          </button>
          <p className="center" style={{ marginTop: 14 }}>
            <button type="button" className="link-btn" style={{ color: 'var(--navy)' }} onClick={toggle}>
              {t('nav.language')}
            </button>
          </p>
        </form>
      </div>
    );
  }

  if (gate === 'denied') {
    return (
      <div className="admin">
        <div className="login">
          <h1>{t('admin.title')}</h1>
          <p className="notice notice-err">{t('admin.notAdmin')}</p>
          <p className="muted small">
            UID: <bdi dir="ltr">{user.uid}</bdi>
          </p>
          <button type="button" className="btn btn-outline" onClick={() => signOut(auth!)}>
            {t('admin.signOut')}
          </button>
        </div>
      </div>
    );
  }

  const tabs: { id: Tab; label: string }[] = [
    { id: 'orders', label: t('admin.tab.orders') },
    { id: 'products', label: t('admin.tab.products') },
    { id: 'categories', label: t('admin.tab.categories') },
    { id: 'settings', label: t('admin.tab.settings') },
  ];

  return (
    <div className="admin">
      <div className="admin-top">
        <div className="container">
          <h1>{t('admin.title')}</h1>
          <div className="admin-top-actions">
            <button type="button" className="lang-btn" onClick={toggle}>
              {t('nav.language')}
            </button>
            <Link to="/" className="btn btn-outline-light btn-sm">
              {t('admin.viewSite')}
            </Link>
            <button type="button" className="btn btn-gold btn-sm" onClick={() => signOut(auth!)}>
              {t('admin.signOut')}
            </button>
          </div>
        </div>
        <div className="container">
          <div className="tabs" role="tablist">
            {tabs.map((x) => (
              <button key={x.id} type="button" role="tab" aria-selected={tab === x.id} className={`tab ${tab === x.id ? 'on' : ''}`} onClick={() => setTab(x.id)}>
                {x.label}
              </button>
            ))}
          </div>
        </div>
      </div>
      <div className="container admin-body">
        {tab === 'orders' && <OrdersAdmin />}
        {tab === 'products' && <ProductsAdmin />}
        {tab === 'categories' && <CategoriesAdmin />}
        {tab === 'settings' && <SettingsAdmin />}
      </div>
    </div>
  );
}
